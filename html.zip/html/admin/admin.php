<?php

require __DIR__.'/../vendor/autoload.php';
require('db.php');

use Firebase\JWT\JWT;
use Firebase\JWT\Key;

$key = 'mustangs';

if (!isset($_COOKIE['auth'])) {
	header('Location: ../index.php');
	exit;
} else {
	$cookie = $_COOKIE['auth'];
	try {
		$decoded = JWT::decode($cookie, new Key($key, 'HS256'));
		$decoded_array = (array) $decoded;
		$user = $decoded_array['username'];
		$isAdmin = $decoded_array['isAdmin'];
        
        if(!$isAdmin) {
            header('Location: ../home.php');
            exit;
        }



	} catch (\Exception $e) {
		header('Location: ../index.php');
		exit;
	}
}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Developer Management System</title>
		<link href="admin.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>Developer Management System</h1>
				<a href="../profile.php"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="../logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>
<div class="content">
                        <h2>Hello admin!</h2>
                        <?php
                                        $stmt = $con->prepare('SELECT file, priority FROM tasks WHERE fixed = 0');
                                        $stmt->execute();
                                        $stmt->bind_result($description, $priority);
                                        $number = 1;
                                        while ($stmt->fetch()) {
                                                $descr = file_get_contents('5bf5dee65aca1cd1497ac8f30ccaf2815e75401e/'.$description);
                                                echo "<div>";
                                                echo "<p>Task number $number</p>";
                                                echo "<table>";
                                                echo "<tr>";
                                                echo "<td>Description: ";
                                                echo htmlspecialchars($descr, ENT_QUOTES, 'UTF-8');
                                                echo "</td>";
                                                echo "</tr>";
                                                echo "<tr>";
                                                echo "<td>Priority: ";
                                                echo htmlspecialchars($priority, ENT_QUOTES, 'UTF-8');
                                                echo "</td>";
                                                echo "</tr>";
                                                echo "<tr>";
                                                echo "<td>Fixed: No</td>";
                                                echo "</tr>";
                                                echo "</table>";
                                                echo "</div>";
                                                $number++;
                                        }
                                        $stmt->close();
                                ?>
                </div>
	</body>
</html>
